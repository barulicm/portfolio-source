#include <iostream>
#include <opencv2/opencv.hpp>
#include <raspicam/raspicam_cv.h>
#include <PiPCA9685/PCA9685.h>
#include <unistd.h>

int main() {
	const auto WIDTH = 320;
	const auto HEIGHT = 240;
	const auto SPEED = 1;
	const auto STEER = 0;
	
	raspicam::RaspiCam_Cv Camera;
	Camera.set(CV_CAP_PROP_FRAME_WIDTH, WIDTH);
	Camera.set(CV_CAP_PROP_FRAME_HEIGHT, HEIGHT);
	if(!Camera.open()) {
		std::cerr << "Couldn't open camera." << std::endl;
		return 1;
	}
	
	PCA9685 pca;
	pca.set_pwm_freq(60.0);
	
	cv::namedWindow("Preview", CV_WINDOW_NORMAL);
	
	cv::Mat frame;
	cv::Mat frame_HSV;
	cv::Mat filtered;
	
	cv::Scalar minVal(0, 100, 100);
	cv::Scalar maxVal(20, 255, 255);
	
	cv::Rect left_roi(0, 0, WIDTH/3, HEIGHT);
	cv::Rect center_roi(WIDTH/3, 0, WIDTH/3, HEIGHT);
	cv::Rect right_roi(2*WIDTH/3, 0, WIDTH/3, HEIGHT);
	
	std::array<cv::Rect, 3> ROIs = {left_roi, center_roi, right_roi};
	std::array<double, 3> PWMs = {1.5, 1.7, 2.0};
	std::array<int, 3> nonZeroCounts = {0,0,0};
	
	pca.set_pwm_ms(SPEED, 1.7);
	usleep(1'000'000);
	pca.set_pwm_ms(SPEED, 1.76);
	
	while(Camera.grab() && cv::waitKey(30) != ' ') {
		Camera.retrieve(frame);
		
		cv::cvtColor(frame, frame_HSV, cv::COLOR_BGR2HSV);
		
		cv::inRange(frame_HSV, minVal, maxVal, filtered);
		
		auto countFunc = [&filtered](cv::Rect &roi) {
			return cv::countNonZero(filtered(roi));
		};
		
		std::transform(ROIs.begin(), ROIs.end(), nonZeroCounts.begin(), countFunc);
		
		auto minIter = std::min_element(nonZeroCounts.begin(), nonZeroCounts.end());
		auto idx = std::distance(nonZeroCounts.begin(), minIter);
		
		cv::rectangle(frame, ROIs[idx], cv::Scalar(0,255,0), 3);
		
		pca.set_pwm_ms(STEER, PWMs[idx]);							
		
		cv::imshow("Preview", frame);
	}
	
	pca.set_pwm_ms(SPEED, 1.7);
	pca.set_pwm_ms(STEER, 1.7);

	return 0;
}








