from picamera import PiCamera
from picamera.array import PiRGBArray
import time
import cv2
from PiPCA9685.PiPCA9685 import PCA9685
import numpy as np

def main():
    WIDTH = 320
    HEIGHT = 240
    STEER = 0
    SPEED = 1
    
    camera = PiCamera()
    camera.resolution = (WIDTH,HEIGHT)
    rawCapture = PiRGBArray(camera, size=(WIDTH,HEIGHT))

    # camera warmp up time
    time.sleep(0.1)

    pca = PCA9685()
    pca.set_pwm_freq(60)

    cv2.namedWindow('Preview', cv2.WINDOW_NORMAL)

    minVal = (0, 100, 100)
    maxVal = (20, 255, 255)

    ROIs = [ [(0,WIDTH//3), (0,HEIGHT)],
             [(WIDTH//3, 2*WIDTH//3), (0, HEIGHT)],
             [(2*WIDTH//3, WIDTH), (0, HEIGHT)] ]

    PWMs = [1.5, 1.7, 2.0]

    pca.set_pwm_ms(SPEED, 1.7)
    time.sleep(1)
    pca.set_pwm_ms(SPEED, 1.76)

    for capture in camera.capture_continuous(rawCapture, format='bgr', use_video_port=True):
        frame = capture.array

        frame_HSV = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        filtered = cv2.inRange(frame_HSV, minVal, maxVal)

        minCount = float('inf')
        minIdx = 0
        
        for i in range(len(ROIs)):
            ROI = ROIs[i]
            count = cv2.countNonZero(filtered[ROI[1][0]:ROI[1][1],ROI[0][0]:ROI[0][1]])
            if count < minCount:
                minCount = count
                minIdx = i

        minROI = ROIs[minIdx]

        cv2.rectangle(frame, (minROI[0][0],minROI[1][0]), (minROI[0][1],minROI[1][1]), color=(0, 255, 0), thickness=3)

        pca.set_pwm_ms(STEER, PWMs[minIdx])

        cv2.imshow('Preview', frame)

        rawCapture.truncate(0)

        if cv2.waitKey(10) == ord(' '):
            break

    pca.set_pwm_ms(SPEED, 1.7)
    pca.set_pwm_ms(STEER, 1.7)
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
