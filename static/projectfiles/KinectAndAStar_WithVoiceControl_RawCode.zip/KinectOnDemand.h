#include <pcl/io/openni_grabber.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

#pragma once

class KinectOnDemand
{
private:
	pcl::Grabber* _interface;

	bool _isWorking;

	pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr _cloud;

	void cloudAvailable(const pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr &cloud);

public:
	KinectOnDemand(void);

	pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr getLatestCloud();

	void shutdown();

	~KinectOnDemand(void);
};

