/*!
  \class ASNode
  Represents an A* node with the following coordinates/values:\n
  - x\n
  - y\n
  - g\n
  - h\n
  - f\n
  - parent (pointer to another ASNode)\n
  - open (boolean flag indicating open/closed status)
*/

#include "ASNode.h"
#include <math.h>

/*!
  Initializes all members to 0 or false;
*/
ASNode::ASNode(void)
{
	_x= 0;
	_y = 0;
	_g = 0;
	_h = 0;
	_parent = 0;
	_open = false;
}

/*!
  Creates a new node with the desired x and y coordinates.
*/
ASNode::ASNode(double x, double y)
{
	_x = x;
	_y = y;
	_g = 0;
	_h = 0;
	_parent = 0;
	_open = false;
}

double ASNode::X()
{
	return _x;
}

double ASNode::Y()
{
	return _y;
}

double ASNode::G()
{
	return _g;
}

double ASNode::H()
{
	return _h;
}

//! Sum of G and H
double ASNode::F()
{
	return _g + _h;
}

void ASNode::X(double val)
{
	_x = val;
}

void ASNode::Y(double val)
{
	_y = val;
}

void ASNode::G(double val)
{
	_g = val;
}

void ASNode::H(double val)
{
	_h = val;
}

ASNode * ASNode::Parent()
{
	return _parent;
}

void ASNode::Parent(ASNode *val)
{
	_parent = val;
}

bool ASNode::Open()
{
	return _open;
}

void ASNode::Open(bool val)
{
	_open = val;
}

/*!
  Returns the distace from this node to p calculated as the square root of the sum of the differences squared.
  \return Sqrt( ( x1 - x2 )^2 + ( y1 - y2 )^2 )
*/
double ASNode::distanceTo(ASNode p)
{
	return sqrt((_x - p._x)*(_x - p._x) + (_y - p._y)*(_y - p._y));
}

ASNode::~ASNode(void)
{
}

/*!
  Sorted by x then by y
*/
bool ASNode::operator< (ASNode o)
{
	if(_x < o._x) return true; else if (_x > o._x) return false;
	if(_y < o._y) return true;
	return false;
}

/*!
  Sorted by x then by y
*/
bool ASNode::operator< (const ASNode o) const
{
	if(_x < o._x) return true; else if (_x > o._x) return false;
	if(_y < o._y) return true;
	return false;
}

/*!
  Returns true if both dimensions of this node and o differ by no more than 0.000000001.
*/
bool ASNode::operator== (ASNode o)
{
	bool answer = abs(_x - o._x) < 0.000000001 && abs(_y - o._y) < 0.000000001;
	return answer;
}