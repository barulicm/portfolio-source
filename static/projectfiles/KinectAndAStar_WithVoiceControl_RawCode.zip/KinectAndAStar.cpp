/*! \file KinectAndAStar.cpp
  
 \brief Entry point for this program.
*/

#include "KMapper.h"
#include "ASPathFinder.h"
#include "KinectOnDemand.h"
#include "TTSHelper.h"
#include "SpeechRecognizer.h"

#include <Aria.h>

#include <vector>

#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/io/vtk_lib_io.h>

#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>

#include <time.h>

#define PI 3.14159265

ArRobot robot;

//! Checks the battery life of the robot and announces if the charge percentage drops below 20%.
double checkBattery(TTSHelper* tts)
{
	robot.lock();
	double volts = robot.getBatteryVoltageNow();
	robot.unlock();

	volts -= 10.0;

	volts /= 5.0;

	volts *= 100.0;

	if(volts < 20)
	{
		std::wstringstream batteryWarningText;
		batteryWarningText << L"Warning! Battery level at ";
		batteryWarningText << volts;
		batteryWarningText << L" percent!";
		tts->Speak(batteryWarningText.str().c_str(), true);
	}

	return volts;
}


//! The main method for the program

int main(int argc, char** argv)
{
	bool useSpeech;
	std::cout << "Use speech? (y/n): ";
	char useSpeechChar;
	std::cin >> useSpeechChar;
	useSpeech = (useSpeechChar == 'y' || useSpeechChar == 'Y');

	TTSHelper tts;

	KinectOnDemand kinect;

#pragma region Robot initialization
	Aria::init();
	ArArgumentParser parser(&argc, argv);
	parser.loadDefaultArguments();
	ArRobotConnector robotConnector(&parser, &robot);

	if(!robotConnector.connectRobot(&robot))
	{
		ArLog::log(ArLog::Normal, "ERROR: Could not connect to robot.\n");
		robotConnector.logOptions();
		Aria::exit(1);
	}
	robot.runAsync(false);
	robot.resetTripOdometer();
	robot.enableMotors();
	double batPercent = checkBattery(&tts);
	std::cout << "Battery: " << batPercent << "%\n";
	if(batPercent > 20)
	{
		std::wstringstream batteryText;
		batteryText << L"Battery level at ";
		batteryText << batPercent;
		batteryText << L" percent!";
		tts.Speak(batteryText.str().c_str(), true);
	}

	robot.setAbsoluteMaxTransVel(200);

	robot.setAbsoluteMaxRotVel(25);

	robot.setHeadingDoneDiff(1.0);

#pragma endregion

#pragma region Get targetx and targety
	double targetx, targety;
	SpeechRecognizer sr(L"SeekurJrGrammar_1.cfg");
	if(useSpeech)
	{
		sr.Pause();
		tts.Speak(L"Please tell me the first dimension of the goal position.", true);
		std::wstring dim1 = L"", dim2 = L"";
		sr.Resume();
		while(dim1.length() == 0)
			dim1 = sr.WaitForRecognition(10000);
		sr.Pause();
		std::cout << "thank you.\n";
		tts.Speak(L"Thank you.", true);

		tts.Speak(L"Please tell me the second dimension of the goal position.", true);
		sr.Resume();
		while(dim2.length() == 0)
			dim2 = sr.WaitForRecognition(10000);
		sr.Pause();
		tts.Speak(L"Thank you.", true);

		double val = 0;
		std::vector<std::wstring> dim1tokens;
		boost::split(dim1tokens, dim1, boost::is_any_of(L" "));
		//parse first digit and add it to val
		//if second token is parsable, multiply val by ten and add second digit
		//if second|third token is 'point'
			//if third|fourth token is parsable, divide this digit by ten and add it to val
			//if fourth|fifth token is parsable, divide this digit by 100 and add it to val
		//if last token is 'forward' set targetX to val
		//if last token is 'backward' set targetX to -val
		//if last token is 'left' set targetY to val
		//if last token is 'right' set targetY to -val
		int index = 0;
		val += boost::lexical_cast<int>(dim1tokens[index]);
		index++;
		try{
			int i = boost::lexical_cast<int>(dim1tokens[index]);
			val *= 10;
			val += i;
			index++;
		} catch (boost::bad_lexical_cast e) {}
		if(find(dim1tokens.begin(), dim1tokens.end(), L"point") != dim1tokens.end())
		{
			try{
				index++;//move past 'point'
				val += (double)(boost::lexical_cast<int>(dim1tokens[index])) / 10.0;
				index++;
				val += (double)(boost::lexical_cast<int>(dim1tokens[index])) / 100.0;
				index++;
			} catch (boost::bad_lexical_cast e) {}
		}
		index++; // move past 'meters'
		if(dim1tokens[index].compare(L"forward")==0)
			targetx = val;
		else if(dim1tokens[index].compare(L"backward")==0)
			targetx = -1 * val;
		else if(dim1tokens[index].compare(L"left")==0)
			targety = val;
		else if(dim1tokens[index].compare(L"right")==0)
			targety = -1 * val;

		index = 0;
		val = 0;
		std::vector<std::wstring> dim2tokens;
		boost::split(dim2tokens, dim2, boost::is_any_of(L" "));
		
		val += boost::lexical_cast<int>(dim2tokens[index]);
		index++;
		try{
			int i = boost::lexical_cast<int>(dim2tokens[index]);
			val *= 10;
			val += i;
			index++;
		} catch (boost::bad_lexical_cast e) {}
		if(find(dim2tokens.begin(), dim2tokens.end(), L"point") != dim2tokens.end())
		{
			try{
				index++;//move past 'point'
				val += (double)(boost::lexical_cast<int>(dim2tokens[index])) / 10.0;
				index++;
				val += (double)(boost::lexical_cast<int>(dim2tokens[index])) / 100.0; 
				index++;
			} catch (boost::bad_lexical_cast e) {}
		}
		index++; // move past 'meters'
		if(dim2tokens[index].compare(L"forward")==0)
			targetx = val;
		else if(dim2tokens[index].compare(L"backward")==0)
			targetx = -1 * val;
		else if(dim2tokens[index].compare(L"left")==0)
			targety = val;
		else if(dim2tokens[index].compare(L"right")==0)
			targety = -1 * val;
		
		std::cout << "targetx: " << targetx << "\ttargety: " << targety << std::endl;

	} else {
		std::cout << "\nPlease type the goal x(forward) coordinate and press enter:";
		std::cin >> targetx;
		std::cout << "\nPlease type the goal y(horizontal) coordinate and press enter:";
		std::cin >> targety;
	}
#pragma endregion

	KMapper mapper;


	pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr inCloud;

	boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer (new pcl::visualization::PCLVisualizer ("Kinect Mapping"));
	viewer->setBackgroundColor(0.3,0.3,0.3);

	pcl::PointCloud<pcl::PointXYZ>::Ptr robotModel (new pcl::PointCloud<pcl::PointXYZ>);
	pcl::PointCloud<pcl::PointXYZRGB>::Ptr targetPoint (new pcl::PointCloud<pcl::PointXYZRGB>);
	pcl::PointXYZRGB target;
	target.z = targetx;
	target.x = -targety;
	target.y = 0;
	target.r = 255;
	target.b = 0;
	target.g = 0;
	targetPoint->push_back(target);

	tts.Speak(L"Please stand back. Seekur Junior will begin moving momentarily.", false);

#pragma region Load SeekurJr model
	pcl::PolygonMesh seekur_mesh;
	pcl::io::loadPolygonFileSTL("SeekurJr_scaled.stl", seekur_mesh);
	pcl::PointCloud<pcl::PointXYZ>::Ptr seekur_model_orig (new pcl::PointCloud<pcl::PointXYZ>);
	pcl::fromROSMsg(seekur_mesh.cloud, *seekur_model_orig);
#pragma endregion

	bool firstloop = true;
	int result;
	std::vector<ASNode> path;
	double stepsize = 0;

	ASNode robotPose = ASNode(-robot.getY() / 1000.0, robot.getX() / 1000.0);
	ASNode end = ASNode(-targety, targetx);

	while( robotPose.distanceTo(end) > 0.175 && !viewer->wasStopped())
	{
		checkBattery(&tts);

		//Get cloud from Kinect
		inCloud = kinect.getLatestCloud();
		while(inCloud == NULL)
		{
			std::cerr << "Null cloud. Trying again...";
			Sleep(250);
			inCloud = kinect.getLatestCloud();
		}
		pcl::PointCloud<pcl::PointXYZRGBA>::Ptr pointcloud (new pcl::PointCloud<pcl::PointXYZRGBA>(*inCloud));


		mapper.AddCloud(pointcloud, robot.getX(), robot.getY(), robot.getTh());

		robotModel->clear();
		Eigen::Vector3f translation(-robot.getY() / 1000.0, 0, robot.getX() / 1000.0);
		Eigen::Quaternionf rotation(Eigen::AngleAxisf(-robot.getTh() * (M_PI / 180.0), Eigen::Vector3f::UnitY()));
		pcl::transformPointCloud(*seekur_model_orig, *robotModel, translation, rotation);

		pcl::PointCloud<pcl::PointXYZ>::Ptr flat_map (new pcl::PointCloud<pcl::PointXYZ>);

		pcl::PointCloud<pcl::PointXYZRGBA>::iterator mapIter;

		pcl::PointCloud<pcl::PointXYZRGBA>::Ptr map = mapper.Map();

		viewer->removeAllPointClouds();
		viewer->removeAllShapes();
		viewer->addPointCloud(map, "map");
		viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 5, "map");

		viewer->addPointCloud(targetPoint, "target");
		viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 6, "target");

		viewer->addPointCloud(robotModel, "robot");
		viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 3, "robot");

		viewer->spinOnce();

		if(firstloop)
		{

			viewer->initCameraParameters();
			viewer->resetCameraViewpoint("map");

			time_t start, end;
			double elapsed, prev = 0;
			time(&start);
			tts.Speak(L"30 seconds.", false);
			do { 

				viewer->removeAllPointClouds();
				viewer->addPointCloud(mapper.Map(), "map");
				viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 5, "map");

				viewer->addPointCloud(targetPoint, "target");
				viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 6, "target");

				viewer->addPointCloud(robotModel, "robot");
				viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 3, "robot");

				viewer->spinOnce();
				time(&end);
				elapsed = difftime(end, start);
				if(elapsed != prev)
				{
					std::cout << 30 - elapsed << std::endl;
					if (elapsed == 10) tts.Speak(L"20 seconds.", false);
					else if (elapsed == 20) tts.Speak(L"10 seconds.", false);
					else if (elapsed == 25) tts.Speak(L"5.", false);
					else if (elapsed == 26) tts.Speak(L"4", false);
					else if (elapsed == 27) tts.Speak(L"3.", false);
					else if (elapsed == 28) tts.Speak(L"2.", false);
					else if (elapsed == 29) tts.Speak(L"1.", false);
				}
				prev = elapsed;
			} while( elapsed < 30);

		}

		viewer->spinOnce();

		flat_map->points.resize(map->points.size());

		int i = 0;

		for(mapIter = map->begin(); mapIter != map->end(); mapIter++)
		{
			pcl::PointXYZRGBA p = *mapIter;

			flat_map->points[i].x = p.x;
			flat_map->points[i].y = p.z;
			flat_map->points[i].z = 0;

			i++;
		}

		robotPose = ASNode(-robot.getY() / 1000.0, robot.getX() / 1000.0);

		stepsize = max(robotPose.distanceTo(end) / 20, 0.1);

		std::cout << "Step size: " << stepsize << std::endl;

		path.clear();
		if(robotPose.distanceTo(end) > 0.175)
			result = ASPathFinder::FindPath(flat_map, stepsize, /*Safety radius*/0.6, robotPose, end, path);
		else
			break;

#pragma region Error results
		if(result == 0)
		{
			std::cerr << "**Could not find path!\n";
			break;
		}
		if(result == -1)
		{
			std::cerr << "**Error finding path!\n";
			break;
		}
		if(result == 2)
		{
			std::cerr << "**Goal is not reachable!\n";
			tts.Speak(L"I'm sorry. The destination you've selected is too close to an obstacle.", true);
			break;
		}
		if(result == 3)
		{
			std::cerr << "**Current position is unreachable!";
			break;
		}
#pragma endregion
		if(result == 1)
		{
			std::cout << "Path found.\n";
			pcl::PointCloud<pcl::PointXYZ>::Ptr path_cloud (new pcl::PointCloud<pcl::PointXYZ>);
			path_cloud->points.resize(path.size());

			for(int i = 0; i < path.size()-1; i++)
			{
				ASNode a = path[i];
				ASNode b = path[i+1];

				viewer->addLine(pcl::PointXYZ(a.X(), 0, a.Y()), pcl::PointXYZ(b.X(), 0, b.Y()), 0, 255, 0, "pathSegment_"+i);
			}

			viewer->spinOnce();

			if(path.size() > 1)
			{
				//Move robot
				ASNode start = path[0];
				ASNode destination = path[1];

				double angle = atan2(destination.Y() - start.Y(), destination.X() - start.X()) * ( 180.0 / PI );
				angle -= 90;

				double trans = start.distanceTo(destination);
				trans *= 1000;
				trans -= 20;

				if(abs(robot.getTh() - angle) > 1 && abs(abs(robot.getTh() - angle) - 360) > 1)
				{
					std::cout << "ANGLES: r: " << robot.getTh() << " desired: " << angle << std::endl;
					tts.Speak(L"Changing direction.", false);
					robot.lock();
					robot.setHeading(angle);
					robot.unlock();
					while(!robot.isHeadingDone()) ArUtil::sleep(100);
				} else {
					tts.Speak(L"Moving forward.", false);
					robot.lock();
					robot.move(trans);
					robot.unlock();
					while(!robot.isMoveDone()) ArUtil::sleep(100);
				}
			}
		}

		viewer->spinOnce();

		if(firstloop) firstloop = false;
	}

	if(robotPose.distanceTo(end) < 0.175)
	{
		std::cout << "******Goal reached!*********\n";
		tts.Speak(L"Mission complete. Thank you for your pay shinse.", true);
	}

	viewer->spin();
	Aria::exit();
	return 0;
}