#pragma once

#include <Windows.h>
#include <atlbase.h>
#include <sapi.h>
#include <sphelper.h>
#include <string>
#include <iostream>

class TTSHelper
{
private:
	CComPtr<ISpVoice> tts;
public:
	TTSHelper(void);
	void Speak(std::wstring textToSpeak, bool waitForFinish);
	~TTSHelper(void);
};

