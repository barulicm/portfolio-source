
#include "TTSHelper.h"


/*!
  Creates a new SAPI Text To Speech voice with the default voice installed on the machine.
*/
TTSHelper::TTSHelper(void)
{
	CComPtr<ISpObjectToken> token;
	HRESULT hr;
	CoInitialize(0);

	tts.CoCreateInstance(CLSID_SpVoice);
	hr = SpGetDefaultTokenFromCategoryId(SPCAT_VOICES, &token, FALSE);
	hr = tts->SetVoice(token);
	hr = tts->SetVolume(100);

	token.Release();
}

/*!
  Sends the text to the SAPI TTS instance to be spoken by the computer.
  \param text The text to be spoken.
  \param wait If true, the method will hang until the TTS is finished; otherwise, the text will be spoken asynchronously and the method will immediately return.
*/
void TTSHelper::Speak(std::wstring text, bool wait)
{
	ULONG n;
	tts->Speak(text.c_str(), SPF_IS_XML | SPF_ASYNC, &n);
	if(wait)
		tts->WaitUntilDone(-1);
}

TTSHelper::~TTSHelper(void)
{
	tts.Release();
	CoUninitialize();
}
