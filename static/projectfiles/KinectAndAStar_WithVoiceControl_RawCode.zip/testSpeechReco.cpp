#include "SpeechRecognizer.h"

int main(int argc, char **argv)
{
	SpeechRecognizer sr(L"SeekurJrGrammar_1.cfg");
	std::wcout << "Ready." << std::endl;
	while(true)
	{
		std::wcout << sr.WaitForRecognition(10000).c_str() << std::endl;
	}
	return 0;
}