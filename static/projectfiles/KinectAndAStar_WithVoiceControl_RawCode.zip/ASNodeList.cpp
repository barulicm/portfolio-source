/*!
  \class ASNodeList
  Manages a list of ASNodes for ASPathFinder.
*/


#include "ASNodeList.h"
#include <algorithm>

ASNodeList::ASNodeList(void)
{
}

/*!
  Adds p to this list if the list does not already contain node p.
  \param p The node to add.
*/
void ASNodeList::addPoint(ASNode p)
{
	if(!contains(p))
		_points.push_back(p);
}

/*!
  Removes p from the list.
  \param p The node to remove.
*/
void ASNodeList::removePoint(ASNode p)
{
	_points.remove(p);
}

/*!
  Returns true if this list contains p.
  \return true if find(...) returns a valid position; otherwise, returns false.
*/
bool ASNodeList::contains(ASNode p)
{
	return (find(_points.begin(), _points.end(), p) != _points.end());
}

/*!
  \return The size of the internal STL list.
*/
int ASNodeList::count()
{
	return _points.size();
}

/*!
  \return The number of nodes in this list who's open flag is set to true.
*/
int ASNodeList::countOpen()
{
	int opencount = 0;
	set_type::iterator iter;
	for(iter = _points.begin(); iter != _points.end(); iter++)
	{
		ASNode n = *iter;
		if( n.Open()) opencount++;
	}
	return opencount;
}

/*!
  \return A pointer to the node with the lowest F value in this list.
*/
ASNode* ASNodeList::getLowestFCost()
{
	ASNode* currentPoint =  &*_points.begin();
	unsigned long nan[2]={0xffffffff, 0x7fffffff};
	double lowestCost = *(double*)nan;
	ASNode* answer;

	set_type::iterator iter;
	for(iter = _points.begin(); iter != _points.end(); iter++)
	{
		currentPoint = &*iter;
		if(currentPoint->Open() && (_isnan(lowestCost) || currentPoint->F() < lowestCost))
		{
			lowestCost = currentPoint->F();
			answer = currentPoint;
		}
	}
	return answer;
}

/*!
  \return A pointer to the node with the lowest H value in this list.
*/
ASNode* ASNodeList::getLowestHCost()
{
	ASNode* currentPoint =  &*_points.begin();
	unsigned long nan[2]={0xffffffff, 0x7fffffff};
	double lowestCost = *(double*)nan;
	ASNode* answer;

	set_type::iterator iter;
	for(iter = _points.begin(); iter != _points.end(); iter++)
	{
		currentPoint = &*iter;
		if(!currentPoint->Open() && (_isnan(lowestCost) || currentPoint->H() < lowestCost))
		{
			lowestCost = currentPoint->H();
			answer = currentPoint;
		}
	}
	return answer;
}

/*!
  \return A pointer to the node in this list whose x and y coordinates match those provided
  \param x
  \param y
*/
ASNode* ASNodeList::getPointWithCoordinates(double x, double y)
{
	set_type::iterator iter;
	ASNode* currentPoint;
	for(iter = _points.begin(); iter != _points.end(); iter++)
	{
		currentPoint = &*iter;
		if(*currentPoint == ASNode(x, y))
			return currentPoint;
	}
	return 0;
}

/*!
  \return A pointer to the node whose x and y coordinates match those of n.
  \param n An ASNode with the desired x and y coordinates.
*/
ASNode* ASNodeList::getPointWithCoordinates(ASNode n)
{
	double x = n.X();
	double y = n.Y();
	set_type::iterator iter;
	ASNode* currentPoint;
	for(iter = _points.begin(); iter != _points.end(); iter++)
	{
		currentPoint = &*iter;
		if(*currentPoint == ASNode(x, y))
			return currentPoint;
	}
	return 0;
}

ASNodeList::~ASNodeList(void)
{
}
