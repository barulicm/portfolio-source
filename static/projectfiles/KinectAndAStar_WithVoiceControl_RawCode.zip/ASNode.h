#pragma once

class ASNode
{
private:
	double _x, _y, _g, _h;
	ASNode *_parent;
	bool _open;
public:
	ASNode(void);
	ASNode(double x, double y);
	ASNode(double x, double y, double g, double h);
	double X();
	double Y();
	double G();
	double H();
	double F();
	void X(double val);
	void Y(double val);
	void G(double val);
	void H(double val);
	ASNode * Parent();
	void Parent(ASNode *val);
	bool Open();
	void Open(bool val);
	double distanceTo(ASNode p);
	~ASNode(void);

	bool operator < (ASNode);
	bool operator < (const ASNode) const;
	bool operator == (ASNode);
};

class ASNodeComparator {
public:
	bool operator() (const ASNode a, const ASNode b) const {
		return a < b;
	}
};

