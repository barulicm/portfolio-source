/*!
  \class KMapper
  Manages the creation of a world map by adding consecutive PointClouds captured at different positions.\n
  Designed for a ground robot in that this class assumes 3-dimensional motion (two dimensions of translation, one of rotation).
*/

#include "KMapper.h"

KMapper::KMapper(void)
{
	firstFrame = true;
	xDisplace = 0;
	yDisplace = 0;
}

/*!
  \return a BOOST shared pointer to the map
*/
pcl::PointCloud<pcl::PointXYZRGBA>::Ptr KMapper::Map()
{
	while(isWorking);
	return map.makeShared();
}

/*!
  Adds a new PointCloud to the map.\n
  This method will transform <i>cloud</i> based on the robot coordinates passed to it, then use Iterative Closest Point to attempt to align the cloud more exactly with the existing map.
  \param cloud A new PCL PointCloud to add to the map.
  \param rx The robot's x coordinate in mm
  \param ry The robot's y coordinate in mm
  \param rt The robot's heading in radians
*/
void KMapper::AddCloud(pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud, double rx, double ry, double rt)
{
	isWorking = true;
	pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud_downsampled (new pcl::PointCloud<pcl::PointXYZRGBA>);
	pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud_intermediatefilter (new pcl::PointCloud<pcl::PointXYZRGBA>);
	pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud_filtered (new pcl::PointCloud<pcl::PointXYZRGBA>);

	//Downsample cloud
	pcl::VoxelGrid<pcl::PointXYZRGBA> vg;
	vg.setInputCloud (cloud);
	vg.setLeafSize (0.075f, 0.075f, 0.075f);
	vg.filter (*cloud_downsampled);

	//Eliminate floor points
	pcl::PassThrough<pcl::PointXYZRGBA> pass;
	pass.setInputCloud(cloud_downsampled);
	pass.setFilterFieldName("y");
	pass.setFilterLimits(0.59, 1.5);
	pass.setFilterLimitsNegative(true);
	pass.filter(*cloud_intermediatefilter);

	//Eliminate points above the top of the robot
	pass.setInputCloud(cloud_intermediatefilter);
	pass.setFilterFieldName("y");
	pass.setFilterLimits(-3.5, -0.01);
	pass.setFilterLimitsNegative(true);
	pass.filter(*cloud_filtered);

	//Transform current cloud to match robot's position (determined via odometry)
	pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud_transformed (new pcl::PointCloud<pcl::PointXYZRGBA>);
	//std::cout << "(" << rx << ", " << ry << ", " << rt << ")\n";
	double mx = -ry / 1000.0;
	double mz =  rx / 1000.0;
	double mt = rt * (M_PI / 180.0);
	Eigen::Vector3f translation(mx, 0, mz);
	Eigen::Quaternionf rotation(Eigen::AngleAxisf(-mt, Eigen::Vector3f::UnitY()));
	pcl::transformPointCloud(*cloud_filtered, *cloud_transformed, translation, rotation);

//	map += *cloud_transformed;

	if(!firstFrame)
	{
		//Use ICP to fix errors in transformation
		pcl::IterativeClosestPoint<pcl::PointXYZRGBA, pcl::PointXYZRGBA> icp;
		icp.setMaxCorrespondenceDistance(2);
		icp.setMaximumIterations(30);
		icp.setInputCloud(cloud_transformed);
		icp.setInputTarget(map.makeShared());
		pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud_aligned (new pcl::PointCloud<pcl::PointXYZRGBA>);
		icp.align(*cloud_aligned);

		if(icp.hasConverged())
		{
			//Add aligned cloud points to map cloud
			map += *cloud_aligned;
			/*Eigen::Matrix4f transform = icp.getFinalTransformation();
			Eigen::Vector2f translation = transform.block<2,1>(0,3);
			xDisplace = translation[0];
			yDisplace = translation[1];*/
		} else {
			//Ignore alignment atempt
			std::cout << "No convergence." << std::endl;
			map += *cloud_transformed;
		}
	} else {
		//Add first cloud's points to map cloud
		map += *cloud_transformed;
	}

	//Run map cloud through a VoxelGrid to remove any duplicate points
	pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud_removedDuplicates (new pcl::PointCloud<pcl::PointXYZRGBA>);
	pcl::VoxelGrid<pcl::PointXYZRGBA> duplicateRemover;
	duplicateRemover.setInputCloud(map.makeShared());
	duplicateRemover.setLeafSize (0.075f, 0.075f, 0.075f);
	duplicateRemover.filter(*cloud_removedDuplicates);

	map.swap(*cloud_removedDuplicates);

	if(firstFrame) firstFrame = false;
	isWorking = false;
}


KMapper::~KMapper(void)
{
}
