/*!
  \class KinectOnDemand
  A wrapper of PCL's OpenNIGrabber that uses a polling API rather than OpenNIGrabber's event driven API.
*/

#include "KinectOnDemand.h"

/*!
  Attempts to create a new OpenNIGrabber and register for its events.
*/
KinectOnDemand::KinectOnDemand(void)
{
	bool connected = false;

	std::cout << "Initializing kinect";

	for(int attempts = 0; attempts < 10 && !connected; attempts++)
	{
		try{
			std::cout << ".";
			_interface = new pcl::OpenNIGrabber();
			connected = true;
		} catch (...)
		{

		}
	}
	std::cout << "Done\n";
	if(!connected)
	{
		std::cerr << "ERROR: Could not initialize Kinect.\n";
		Sleep(3000);
		std::exit(1);
	}

	_isWorking = true;

	boost::function<void (const pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr&)> callback = boost::bind (&KinectOnDemand::cloudAvailable, this, _1);

	_interface->registerCallback(callback);

	_interface->start();
}

/*!
  Callback method used to update cloud.
*/
void KinectOnDemand::cloudAvailable(const pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr &cloud)
{
	_isWorking = true;

	_cloud = cloud;

	_isWorking = false;
}

/*!
  \return The most recent cloud recieved from the kinect.
*/
pcl::PointCloud<pcl::PointXYZRGBA>::ConstPtr KinectOnDemand::getLatestCloud()
{
	while(!_interface->isRunning()){}

	while(_isWorking){}

	return _cloud;
}

/*!
  Stops the OpenNIGrabber.\n
  <b>Important!</b> Should <i>always</i> be called before the program ends.
*/
void KinectOnDemand::shutdown()
{
	_interface->stop();
}

KinectOnDemand::~KinectOnDemand(void)
{
}
