#pragma once

#include "ASNode.h"
#include <list>

using namespace std;

#define set_type list<ASNode>

class ASNodeList
{
	set_type _points;
public:
	ASNodeList(void);
	void addPoint(ASNode p);
	void removePoint(ASNode p);
	int indexOf(ASNode p);
	bool contains(ASNode p);
	int count();
	int countOpen();
	ASNode* getLowestFCost();
	ASNode* getLowestHCost();
	ASNode* getPointWithCoordinates(double x, double y);
	ASNode* getPointWithCoordinates(ASNode n);
	~ASNodeList(void);
};

