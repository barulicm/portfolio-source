#pragma once

#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/registration/icp.h>

class KMapper
{
private:
	pcl::PointCloud<pcl::PointXYZRGBA> map;
	bool firstFrame;
	bool isWorking;
	double xDisplace;
	double yDisplace;
public:
	KMapper(void);
	pcl::PointCloud<pcl::PointXYZRGBA>::Ptr Map();
	void AddCloud(pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud, double x, double y, double th);
	void getDisplacements(double& x, double& y);
	~KMapper(void);
};

