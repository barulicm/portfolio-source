#pragma once
#include "ASNodeList.h"
#include "ASNode.h"
#include <vector>
#include <pcl\point_types.h>

class ASPathFinder
{
public:
	static int FindPath(pcl::PointCloud<pcl::PointXYZ>::Ptr map, double step, float safetyRadius, ASNode start, ASNode finish, vector<ASNode>& path);
	static bool nodeIsOccupied(pcl::PointCloud<pcl::PointXYZ>::Ptr map, ASNode node, float radius);
	static bool closeEnoughForFinish(ASNode point, ASNode finish, double stepsize);
private:
	static void smoothPath(pcl::PointCloud<pcl::PointXYZ>::Ptr map, float radius, double stepsize, vector<ASNode>& path);
	static bool lineOfSite(pcl::PointCloud<pcl::PointXYZ>::Ptr map, float radius, ASNode start, ASNode end);
};

