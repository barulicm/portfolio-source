#pragma once

#include <Windows.h>
#include <sphelper.h>

#pragma warning(disable:4995)
#include <iostream>
#include <string>

class SpeechRecognizer
{
private:
	HANDLE hEvent;
	HRESULT hr;
	CSpEvent evt;
	SPPHRASE *pParts;
	ISpPhrase *pPhrase;
	CComPtr<ISpRecognizer> cpEngine;
	CComPtr<ISpRecoContext> cpRecoCtx;
	CComPtr<ISpRecoGrammar> cpGram;
public:
	SpeechRecognizer(wchar_t* grammarURL);
	std::wstring WaitForRecognition(DWORD milliseconds);
	std::wstring WaitForRecognitionInfinite();
	void Pause();
	void Resume();
	~SpeechRecognizer(void);
};

