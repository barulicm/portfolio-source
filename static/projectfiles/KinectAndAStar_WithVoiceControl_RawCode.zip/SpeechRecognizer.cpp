#include "SpeechRecognizer.h"

/*!
  Creates a new SAPI SharedRecognizer and RecognitionContext given the grammar file at grammarURL.
  \param grammarURL path to the grammar file to be used by this SpeechRecognizer
*/
SpeechRecognizer::SpeechRecognizer(wchar_t* grammarURL)
{
	CoInitialize(0);

	hr = cpEngine.CoCreateInstance(CLSID_SpSharedRecognizer);
	hr= cpEngine->CreateRecoContext(&cpRecoCtx);

	hr = cpRecoCtx->SetNotifyWin32Event();
	hEvent = cpRecoCtx->GetNotifyEventHandle();
	ULONGLONG ullEvents = SPFEI(SPEI_RECOGNITION) | SPFEI(SPEI_FALSE_RECOGNITION);
	hr = cpRecoCtx->SetInterest(ullEvents, ullEvents);
	
	hr = cpRecoCtx->CreateGrammar(1, &cpGram);
	hr = cpGram->LoadCmdFromFile(grammarURL, SPLO_STATIC);

	hr = cpGram->SetRuleState(0,0,SPRS_ACTIVE);
}

/*!
  Waits for either a sucesful or false recognition from the SAPI recognizer. If no events are recieved after the specified delay, an empty string is returned.
  \param milliseconds delay in milliseconds
  \return The recognized phrase or empty string if no phrase is recognized in the allotted time.
*/
std::wstring SpeechRecognizer::WaitForRecognition(DWORD milliseconds)
{
	WaitForSingleObject(hEvent, milliseconds);

	LPWSTR pwscText;
	std::wstring answer;

	while(evt.GetFrom(cpRecoCtx) == S_OK)
	{
		if(evt.eEventId != SPEI_FALSE_RECOGNITION)
		{
			pPhrase = evt.RecoResult();
			hr = pPhrase->GetPhrase(&pParts);
			hr = pPhrase->GetText(SP_GETWHOLEPHRASE, SP_GETWHOLEPHRASE, FALSE, &pwscText, 0);

			answer = std::wstring(pwscText);

			CoTaskMemFree(pParts);
			CoTaskMemFree(pwscText);

		}
	}

	return answer;
}

/*!
  Waits infinitely for either a sucesful or false recognition from the SAPI recognizer.
  \return The recognized phrase.
*/
std::wstring SpeechRecognizer::WaitForRecognitionInfinite()
{
	return WaitForRecognition(INFINITE);
}

/*!
  Pauses the recognition context so that no phrases from this grammar will fire events.
*/
void SpeechRecognizer::Pause()
{
	cpRecoCtx->Pause(0);
}

/*!
  Resumes recognition so that phrases from this grammar will fire events again.
*/
void SpeechRecognizer::Resume()
{
	cpRecoCtx->Resume(0);
}

SpeechRecognizer::~SpeechRecognizer(void)
{

	cpGram.Release();
	cpRecoCtx.Release();
	cpEngine.Release();

	CoUninitialize();
}
