/*!
  \class ASPathFinder
  Implements the A* path finding algorithm.\n
  This particular implementation is based on the following tutorial:\n
  http://www.policyalmanac.org/games/aStarTutorial.htm
*/
#include "ASPathFinder.h"
#include <stack>
#include <pcl/kdtree/kdtree_flann.h>

#define PI 3.14159265

/*!
  \brief Finds a path from <i>start</i> to <i>finish</i> through <i>map</i>.
  This method finds a path from <i>start</i> to <i>finish</i> through <i>map</i> and stores it in <i>path</i>.\n
  \param map A map of the environment in a PCL PointCloud. Although PCL is designed for 3D data, this particular method is designed to implement a 2D algorithm. Thus, map should be a PointCloud whose points all have 0 as their Z coordinate.
  \param stepsize The length of one side of a square in the search grid.
  \param radius The minimum distance between a node and all points in <i>map</i> for that node to be considered drivable.
  \param start The starting node
  \param finish The goal node
  \param path A STL vector that is filled with the nodes that make up the path.
  \return 1 if path found\n 0 if unable to find path\n 2 if the goal is not a drivable location\n -1 if there was an error finding the path
*/
int ASPathFinder::FindPath(pcl::PointCloud<pcl::PointXYZ>::Ptr map, double stepsize, float radius, ASNode start, ASNode finish, vector<ASNode>& path)
{

	if(nodeIsOccupied(map, finish, radius))
	{
		//Finish is not a drivable location
		return 2;
	}

	ASNodeList* nodes = new ASNodeList();

	start.Open(true);
	start.H(start.distanceTo(finish));
	nodes->addPoint(start);

	do {

		ASNode* currentNode = nodes->getLowestFCost();

		//Move current point from open to closed
		currentNode->Open(false);

		//For each neighboor point...
		for(double x = currentNode->X() - stepsize; x <= currentNode->X()+stepsize; x+=stepsize)
		{
			for(double y = currentNode->Y() - stepsize; y <= currentNode->Y() + stepsize; y+=stepsize)
			{
				ASNode currentNeighbor = ASNode(x, y);
				currentNeighbor.H(currentNeighbor.distanceTo(finish));

				if(closeEnoughForFinish(currentNeighbor, finish, stepsize))
					currentNeighbor = finish;

				if(*currentNode == currentNeighbor)
					continue;

				if(nodes->contains(currentNeighbor))
				{
					currentNeighbor = *(nodes->getPointWithCoordinates(currentNeighbor.X(), currentNeighbor.Y()));

					if(currentNeighbor.Open())
					{
						//Open
						//Use G-Cost to determine whether currentPoint is a better parent for currentNeighbor.
						double currentGCost = currentNeighbor.G();
						double possibleGCost = currentNode->G() + currentNeighbor.distanceTo(*currentNode);
						if(possibleGCost < currentGCost)
						{
							currentNeighbor.G(possibleGCost);
							currentNeighbor.Parent(&(*currentNode));
						}
					}
					//else closed
				}
				else {
					//Unexplored
					if(!nodeIsOccupied(map, currentNeighbor, radius))
					{
						currentNeighbor.G(currentNode->G() + currentNeighbor.distanceTo(*currentNode));

						currentNeighbor.Parent(&(*currentNode));

						currentNeighbor.Open(true);

						nodes->addPoint(currentNeighbor);
					}
				}
			}
		}

		//std::cout << nodes->getLowestHCost()->H() << std::endl;

	} while( (!nodes->contains(finish) || nodes->getPointWithCoordinates(finish)->Open()) && nodes->countOpen() > 0);

	if((nodes->contains(finish) && !nodes->getPointWithCoordinates(finish)->Open()))
	{
		//Path found

		//Starting at finish, use the parent pointers to trace the path in reverse
		stack<ASNode> reversePath = stack<ASNode>();
		ASNode* currentPoint = nodes->getPointWithCoordinates(finish);
		reversePath.push(*currentPoint);
		while( !(*currentPoint == start) )
		{
			currentPoint = (currentPoint->Parent());
			reversePath.push(*currentPoint);
		}
		//Reverse the order of this traced path to get the real path
		while(!reversePath.empty())
		{
			path.push_back(reversePath.top());
			reversePath.pop();
		}

		smoothPath(map, radius, stepsize, path);

		return 1;
	}
	else if(nodes->countOpen() == 0)
	{
		//No path found
		return 0;
	}

	return -1;
}

/*!
  Checks if <i>node</i> is a drivable location in <i>map</i>.
  \param map A PCL PointCloud (2D - see FindPath())
  \param node The node to check
  \param radius The minimum distance between a node and all points in <i>map</i> for that node to be considered drivable.
  \return <i>True</i> if the node is <b>NOT</b> drivable, and <i>false</i> if the node <b>IS</b> drivable.
*/
bool ASPathFinder::nodeIsOccupied(pcl::PointCloud<pcl::PointXYZ>::Ptr map, ASNode node, float radius)
{
	pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;

	kdtree.setInputCloud(map);

	pcl::PointXYZ searchPoint;

	searchPoint.x = (float)node.X();
	searchPoint.y = (float)node.Y();
	searchPoint.z = 0;

	std::vector<int> pointIdxRadiusSearch;
	std::vector<float> pointRadiusSquaredDistance;

	if ( kdtree.radiusSearch (searchPoint, radius, pointIdxRadiusSearch, pointRadiusSquaredDistance) > 0)
	{
		return true;
	}
	return false;

}

/*!
  \return True if the distance between <i>n</i> and <i>f</i> is less than <i>step</i>; otherwise, false.
*/
bool ASPathFinder::closeEnoughForFinish(ASNode n, ASNode f, double step)
{
	return n.distanceTo(f) <= step;
}

/*!
  Simplifies path by removing all nodes between any pair of nodes that have a clear line of site between them.
  \param map A PCL PointCloud (2D - see FindPath())
  \param radius The minimum distance between a node and all points in <i>map</i> for that node to be considered drivable.
  \param stepsize The length of one side of a square in the search grid.
  \param path A STL vector containing the nodes of the path in order. <b>NOTE:</b> This is also the output, meaning this vector will be modified to hold the result of this algorithm.
*/
void ASPathFinder::smoothPath(pcl::PointCloud<pcl::PointXYZ>::Ptr map, float radius, double stepsize, vector<ASNode>& path)
{
#pragma region Eliminate unnecessary corners
	for(int i = 0; i < path.size()-2; i++)
	{
		ASNode start = path[i];
		vector<ASNode>::iterator iter = path.begin() + i + 2;
	
		for(int j = i+2; j < path.size(); j++)
		{
			ASNode end = *iter;
			if( lineOfSite(map, radius, start, end) )
			{
				iter = path.erase(iter-1);
				j--;
			}
			iter++;
		}
	}
#pragma endregion

#pragma region Fill in straight shots with steps
	//vector<ASNode>::iterator iter;
	//for(iter = path.begin(); iter != path.end()-1; iter++)
	//{
	//	ASNode a = *iter;
	//	ASNode b = *(iter + 1);

	//	double dist = a.distanceTo(b);
	//	int steps = dist / stepsize;

	//	if(steps > 1)
	//	{
	//		for(int n = 0; n < steps; n++)
	//		{
	//			double angle = atan2(b.Y() - a.Y(),b.X() - a.X());
	//			double nx = (cos(angle) * stepsize * (n+1)) + a.X();
	//			double ny = (sin(angle) * stepsize * (n+1)) + a.Y();
	//			iter = path.insert(++iter, ASNode(nx, ny));
	//		}
	//	}
	//}
#pragma endregion

}

/*!
  Checks to see if there is a drivable straight line between <i>start</i> and <i>end</i>
  \param map A PCL PointCloud (2D - see FindPath())
  \param radius The minimum distance between a node and all points in <i>map</i> for that node to be considered drivable.
  \param start The starting node
  \param end The ending node
  \return <i>True</i> if there is a line of sight; otherwise, <i>false</i>.
*/
bool ASPathFinder::lineOfSite (pcl::PointCloud<pcl::PointXYZ>::Ptr map, float radius, ASNode start, ASNode end)
{
	/*pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;

	kdtree.setInputCloud(map);

	pcl::PointXYZ searchPoint;
	searchPoint.z = 0;

	double angle = atan2(end.Y() - start.Y(), end.X() - start.X());
	
	std::vector<int> pointIdxRadiusSearch;
	std::vector<float> pointRadiusSquaredDistance;

	int steps = start.distanceTo(end) / 0.1;

	for(int n=0; n < steps; n++)
	{
		pointIdxRadiusSearch.clear();
		pointRadiusSquaredDistance.clear();

		searchPoint.x = cos(angle) * 0.1 * n + start.X();
		searchPoint.y = sin(angle) * 0.1 * n + start.Y();

		if ( kdtree.radiusSearch (searchPoint, radius, pointIdxRadiusSearch, pointRadiusSquaredDistance) > 0)
		{
			return false;
		}
	}
	return true;*/

	double dist, ax, ay, bx, by, px, py, abx, aby, padotb;

	pcl::PointCloud<pcl::PointXYZ>::iterator iter;

	for (iter = map->begin(); iter != map->end(); iter++)
	{
		ay = start.Y();
		ax = start.X();
		by = end.Y();
		bx = end.X();

		pcl::PointXYZ point = *iter;
		px = point.x;
		py = point.y;

		ax -= px; ay -= py; bx -= px; by -= py;
		abx = ax - bx; aby = ay - by;

		if( ( ( bx * (-abx) ) + ( by * (-aby) ) ) <= 0 )
			dist = sqrt(bx*bx + by*by);
		else if( (padotb = (ax*abx)+(ay*aby)) <= 0 )
			dist = sqrt(ax*ax + ay*ay);
		else
			dist = sqrt((ax*ax+ay*ay)*(1-(padotb*padotb/((ax*ax+ay*ay)*abx*abx+(ax*ax+ay*ay)*aby*aby))));

		if(dist <= radius)
		{
			return false;
		}
	}

	return true;
}